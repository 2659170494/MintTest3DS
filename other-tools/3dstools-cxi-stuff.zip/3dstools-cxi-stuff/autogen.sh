aclocal
autoconf
automake --add-missing -c
