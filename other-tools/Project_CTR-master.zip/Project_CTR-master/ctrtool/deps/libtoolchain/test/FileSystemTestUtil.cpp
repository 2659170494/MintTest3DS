#include "FileSystemTestUtil.h"

const std::string FileSystemTestUtil::DummyFileSystemBase::kClassName = "DummyFileSystemBase";