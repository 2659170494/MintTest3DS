# libmbedtls
Cryptographic functions. Clone of [mbedtls 2.16.5](https://github.com/ARMmbed/mbedtls/tree/mbedtls-2.16).
