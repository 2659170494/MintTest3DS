# libnintendo-n3ds
C++ Library for parsing Nintendo 3DS file formats
