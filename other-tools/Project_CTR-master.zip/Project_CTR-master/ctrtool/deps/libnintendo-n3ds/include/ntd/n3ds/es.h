#pragma once

//#include <ntd/n3ds/es/Certficate.h>
#include <ntd/n3ds/es/Ticket.h>
#include <ntd/n3ds/es/TitleMetaData.h>