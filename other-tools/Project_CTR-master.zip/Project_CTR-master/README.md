# Project_CTR
Project CTR is a collection of custom Nintendo 3DS tools.

## Tools
[ctrtool](ctrtool/README.md) - a tool to read/extract Nintendo 3DS files. ([download](https://github.com/3DSGuy/Project_CTR/releases/tag/ctrtool-v1.1.0))

[makerom](makerom/README.md) - creates CTR cxi/cfa/cci/cia files. ([download](https://github.com/3DSGuy/Project_CTR/releases/tag/makerom-v0.18.3)) 
